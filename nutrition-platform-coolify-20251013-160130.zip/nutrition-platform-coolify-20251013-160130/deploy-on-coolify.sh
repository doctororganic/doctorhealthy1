#!/bin/bash
set -e

echo "🚀 Deploying to Coolify..."
echo "=========================="

# Load environment variables
set -a
source .env.production 2>/dev/null || echo "No .env.production found"
set +a

# Create necessary directories
mkdir -p logs data uploads backups

# Initialize database if needed
echo "🗄️  Setting up database..."
if [ -f "backend/migrations/init.sql" ]; then
    echo "Running database migrations..."
    # Database migrations would run here
fi

# Set proper permissions
chmod -R 755 /app
chmod -R 777 logs data uploads backups

# Start services
echo "🐳 Starting services..."
docker-compose -f docker-compose.production.yml up -d --build

# Wait for services
sleep 30

# Health check
echo "🔍 Performing health checks..."
if curl -f -k https://localhost:8080/health > /dev/null 2>&1; then
    echo "✅ HTTPS Health check passed"
elif curl -f http://localhost:8080/health > /dev/null 2>&1; then
    echo "✅ HTTP Health check passed"
else
    echo "❌ Health check failed"
    exit 1
fi

echo ""
echo "🎉 Deployment successful!"
echo "========================"
echo "🌐 Access: https://super.doctorhealthy1.com"
echo "🔍 Health: https://super.doctorhealthy1.com/health"
echo "📚 API: https://super.doctorhealthy1.com/api/v1/info"
