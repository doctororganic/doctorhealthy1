package services

type UserService struct{}

func NewUserService() *UserService {
	return &UserService{}
}
