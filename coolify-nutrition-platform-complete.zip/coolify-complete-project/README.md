# 🍎 Trae New Healthy1 - Complete Full-Stack Nutrition Platform

A comprehensive AI-powered nutrition and health management platform with integrated frontend and backend, designed for easy deployment with Coolify.

## 🎯 Features

- **🧠 AI Nutrition Analysis** - Advanced food nutritional analysis with halal verification
- **🕌 Religious Dietary Compliance** - Halal, kosher, and dietary restriction checking
- **📊 Comprehensive Data** - Complete nutritional breakdown with medical disclaimers
- **🍽️ Diet Plans** - Evidence-based diet recommendations with macro calculations
- **👨‍🍳 Recipe Database** - Healthy recipes with nutritional information
- **📱 Integrated Frontend** - Modern web interface with RTL Arabic support
- **🌍 Multi-language Support** - English and Arabic localization
- **⚡ Real-time Processing** - Instant calculations and API responses
- **🔒 Secure API** - JWT authentication with request signing
- **📊 Analytics** - Usage tracking and performance monitoring

## 🚀 Quick Deploy to Coolify

### Method 1: Upload ZIP File

1. **Download the complete project ZIP:**
   ```bash
   # The coolify-complete-project directory contains everything needed
   zip -r coolify-nutrition-platform.zip coolify-complete-project/
   ```

2. **Create New Application in Coolify:**
   - Go to your Coolify dashboard
   - Select your "new doctorhealthy1" project
   - Click "Create Application"
   - Choose "Upload ZIP" as source
   - Upload the `coolify-nutrition-platform.zip` file

3. **Configure Application:**
   - **Name:** `nutrition-platform-complete`
   - **Build Pack:** `Dockerfile`
   - **Dockerfile Location:** `Dockerfile` (leave default)
   - **Port:** `8080`

4. **Set Environment Variables:**
   ```bash
   # Server Configuration
   SERVER_PORT=8081
   ENVIRONMENT=development

   # Security (Generate new secure values)
   JWT_SECRET=your_secure_jwt_secret_here
   API_KEY_SECRET=your_secure_api_key_secret_here
   ENCRYPTION_KEY=your_secure_encryption_key_here

   # CORS Configuration
   CORS_ALLOWED_ORIGINS=https://super.doctorhealthy1.com,https://www.super.doctorhealthy1.com,http://localhost:3000

   # Database (SQLite for simplicity)
   DB_HOST=localhost
   DB_PORT=5432
   DB_SSL_MODE=disable

   # Other settings
   LOG_LEVEL=info
   DATA_PATH=./data
   NUTRITION_DATA_PATH=./data
   DEFAULT_LANGUAGE=en
   SUPPORTED_LANGUAGES=en,ar
   HEALTH_CHECK_ENABLED=true
   ```

5. **Deploy!**

### Method 2: Git Repository Deployment

1. **Upload this project to GitHub/GitLab**
2. **In Coolify, select "Git Repository"**
3. **Connect your repository**
4. **Set build pack to "Dockerfile"**
5. **Configure environment variables as above**
6. **Deploy!**

## 📋 API Endpoints

### Core Endpoints
- `GET /` - Modern web interface with interactive features
- `GET /health` - Health check and system status
- `GET /api/info` - API information and documentation

### Nutrition Analysis
- `POST /api/nutrition/analyze` - Comprehensive nutrition analysis
- `POST /api/generate-meal-plan` - AI-powered meal plan generation
- `POST /api/generate-workouts` - Personalized workout plans
- `POST /api/generate-lifestyle-plan` - Health condition management
- `POST /api/generate-recipes` - Recipe generation with preferences

### Data Endpoints
- `GET /api/v1/foods` - Food database with search
- `GET /api/v1/exercises` - Exercise database
- `GET /api/v1/recipes` - Recipe collection
- `GET /api/v1/health/conditions` - Health condition data

## 🔧 Configuration

### Environment Variables

#### Required
- `SERVER_PORT` - Backend server port (default: 8081)
- `JWT_SECRET` - JWT signing secret (generate securely)
- `API_KEY_SECRET` - API key encryption secret
- `ENCRYPTION_KEY` - Data encryption key

#### Optional
- `ENVIRONMENT` - development/production (default: production)
- `CORS_ALLOWED_ORIGINS` - Allowed CORS origins
- `LOG_LEVEL` - Logging level (default: info)
- `DATA_PATH` - Data files path (default: ./data)
- `DEFAULT_LANGUAGE` - Default language (default: en)

### Health Check
The application includes comprehensive health checks:
- HTTP health endpoint at `/health`
- Database connectivity checks
- System resource monitoring
- Automatic service discovery

## 🌐 Frontend Features

- **Modern UI** - Clean, responsive design
- **RTL Support** - Full Arabic language support
- **Interactive Forms** - Real-time nutrition analysis
- **API Integration** - Seamless backend connectivity
- **Offline Support** - Service worker caching
- **Progressive Web App** - Installable on mobile devices

## 🏗️ Architecture

```
coolify-complete-project/
├── Dockerfile              # Multi-stage build
├── docker-compose.yml      # Local development
├── cmd/server/main.go      # Backend entry point
├── main.go                 # Full application
├── go.mod                  # Go dependencies
├── frontend/               # Static web files
│   ├── index.html
│   ├── css/
│   ├── js/
│   └── locales/
├── data/                   # Nutrition data files
├── nginx/                  # Web server config
│   ├── nginx.conf
│   └── conf.d/
└── README.md
```

## 🔒 Security Features

- **JWT Authentication** - Secure API access
- **Request Signing** - Prevent replay attacks
- **CORS Protection** - Configurable origin restrictions
- **Rate Limiting** - API abuse prevention
- **Input Validation** - Comprehensive data validation
- **SQL Injection Protection** - Parameterized queries
- **XSS Prevention** - Content security headers

## 📊 Monitoring

- **Health Checks** - Automatic service monitoring
- **API Analytics** - Usage tracking and metrics
- **Error Logging** - Comprehensive error reporting
- **Performance Metrics** - Response time monitoring
- **Database Monitoring** - Connection pool statistics

## 🎯 Usage Examples

### Nutrition Analysis
```bash
curl -X POST https://your-domain.com/api/nutrition/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "food": "chicken breast",
    "quantity": 150,
    "unit": "g",
    "checkHalal": true
  }'
```

### Meal Plan Generation
```bash
curl -X POST https://your-domain.com/api/generate-meal-plan \
  -H "Content-Type: application/json" \
  -d '{
    "age": 30,
    "gender": "male",
    "height": 175,
    "weight": 70,
    "activityLevel": "moderate",
    "goal": "maintain"
  }'
```

## 🐛 Troubleshooting

### Common Issues

1. **Application won't start:**
   - Check environment variables
   - Verify data directory permissions
   - Check Docker logs

2. **API returns 500 errors:**
   - Check database connectivity
   - Verify API key configuration
   - Check application logs

3. **Frontend not loading:**
   - Verify nginx configuration
   - Check static file paths
   - Clear browser cache

4. **CORS errors:**
   - Update CORS_ALLOWED_ORIGINS
   - Check domain configuration
   - Verify SSL certificates

## 📞 Support

For issues and questions:
1. Check the Coolify application logs
2. Verify environment variable configuration
3. Test API endpoints individually
4. Check network connectivity

## 🚀 Production Deployment Checklist

- [ ] Environment variables configured
- [ ] SSL certificates installed
- [ ] Domain DNS configured
- [ ] Database backups scheduled
- [ ] Monitoring alerts set up
- [ ] API keys generated
- [ ] Frontend assets optimized
- [ ] Health checks passing

---

**Built with ❤️ for better health and nutrition worldwide**