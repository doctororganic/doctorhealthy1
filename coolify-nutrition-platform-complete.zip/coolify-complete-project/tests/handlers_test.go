package tests

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/labstack/echo/v4"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/suite"

	"nutrition-platform/handlers"
	"nutrition-platform/models"
)

// MockService represents a mock service for testing
type MockService struct {
	mock.Mock
}

func (m *MockService) GetUser(id int) (*models.User, error) {
	args := m.Called(id)
	return args.Get(0).(*models.User), args.Error(1)
}

func (m *MockService) CreateUser(user *models.User) error {
	args := m.Called(user)
	return args.Error(0)
}

func (m *MockService) GetFood(id int) (*models.Food, error) {
	args := m.Called(id)
	return args.Get(0).(*models.Food), args.Error(1)
}

func (m *MockService) SearchFoods(query string) ([]*models.Food, error) {
	args := m.Called(query)
	return args.Get(0).([]*models.Food), args.Error(1)
}

func (m *MockService) LogFood(userID, foodID int, quantity float64, mealType string) error {
	args := m.Called(userID, foodID, quantity, mealType)
	return args.Error(0)
}

// HandlersTestSuite tests handler functionality
type HandlersTestSuite struct {
	suite.Suite
	echo        *echo.Echo
	mockService *MockService
	handler     *handlers.Handler
}

// SetUpSuite initializes the test suite
func (suite *HandlersTestSuite) SetUpSuite() {
	suite.echo = echo.New()
	suite.mockService = new(MockService)
	suite.handler = handlers.NewHandler(suite.mockService)
}

// SetUpTest runs before each test
func (suite *HandlersTestSuite) SetUpTest() {
	suite.mockService.ExpectedCalls = nil
}

// TearDownSuite cleans up after tests
func (suite *HandlersTestSuite) TearDownSuite() {
	// Cleanup resources
}

// TestGetUserHandler tests the GetUser handler
func (suite *HandlersTestSuite) TestGetUserHandler() {
	// Setup mock
	expectedUser := &models.User{
		ID:       1,
		Username: "testuser",
		Email:    "test@example.com",
		Age:      25,
		Gender:   "male",
		Height:   175.5,
		Weight:   70.0,
	}
	suite.mockService.On("GetUser", 1).Return(expectedUser, nil)

	// Create request
	req := httptest.NewRequest(http.MethodGet, "/users/1", nil)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)
	c.SetParamNames("id")
	c.SetParamValues("1")

	// Execute handler
	err := suite.handler.GetUser(c)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), http.StatusOK, rec.Code)

	var response models.User
	err = json.Unmarshal(rec.Body.Bytes(), &response)
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), expectedUser.ID, response.ID)
	assert.Equal(suite.T(), expectedUser.Username, response.Username)

	suite.mockService.AssertExpectations(suite.T())
}

// TestCreateUserHandler tests the CreateUser handler
func (suite *HandlersTestSuite) TestCreateUserHandler() {
	// Setup test data
	newUser := &models.User{
		Username: "newuser",
		Email:    "newuser@example.com",
		Age:      30,
		Gender:   "female",
		Height:   165.0,
		Weight:   60.0,
	}

	suite.mockService.On("CreateUser", mock.AnythingOfType("*models.User")).Return(nil)

	// Create request
	userJSON, _ := json.Marshal(newUser)
	req := httptest.NewRequest(http.MethodPost, "/users", bytes.NewBuffer(userJSON))
	req.Header.Set(echo.HeaderContentType, echo.MIMEApplicationJSON)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)

	// Execute handler
	err := suite.handler.CreateUser(c)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), http.StatusCreated, rec.Code)

	suite.mockService.AssertExpectations(suite.T())
}

// TestCreateUserHandlerInvalidJSON tests CreateUser with invalid JSON
func (suite *HandlersTestSuite) TestCreateUserHandlerInvalidJSON() {
	// Create request with invalid JSON
	req := httptest.NewRequest(http.MethodPost, "/users", strings.NewReader("invalid json"))
	req.Header.Set(echo.HeaderContentType, echo.MIMEApplicationJSON)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)

	// Execute handler
	err := suite.handler.CreateUser(c)

	// Assertions
	assert.Error(suite.T(), err)
}

// TestGetFoodHandler tests the GetFood handler
func (suite *HandlersTestSuite) TestGetFoodHandler() {
	// Setup mock
	expectedFood := &models.Food{
		ID:        1,
		Name:      "Apple",
		Category:  "Fruit",
		Calories:  52,
		Protein:   0.3,
		Carbs:     14.0,
		Fat:       0.2,
		Fiber:     2.4,
		Sugar:     10.4,
		Sodium:    1,
		Potassium: 107,
		Vitamin_C: 4.6,
		Calcium:   6,
		Iron:      0.12,
	}
	suite.mockService.On("GetFood", 1).Return(expectedFood, nil)

	// Create request
	req := httptest.NewRequest(http.MethodGet, "/foods/1", nil)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)
	c.SetParamNames("id")
	c.SetParamValues("1")

	// Execute handler
	err := suite.handler.GetFood(c)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), http.StatusOK, rec.Code)

	var response models.Food
	err = json.Unmarshal(rec.Body.Bytes(), &response)
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), expectedFood.ID, response.ID)
	assert.Equal(suite.T(), expectedFood.Name, response.Name)

	suite.mockService.AssertExpectations(suite.T())
}

// TestSearchFoodsHandler tests the SearchFoods handler
func (suite *HandlersTestSuite) TestSearchFoodsHandler() {
	// Setup mock
	expectedFoods := []*models.Food{
		{
			ID:       1,
			Name:     "Apple",
			Category: "Fruit",
			Calories: 52,
		},
		{
			ID:       2,
			Name:     "Banana",
			Category: "Fruit",
			Calories: 89,
		},
	}
	suite.mockService.On("SearchFoods", "fruit").Return(expectedFoods, nil)

	// Create request
	req := httptest.NewRequest(http.MethodGet, "/foods/search?q=fruit", nil)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)

	// Execute handler
	err := suite.handler.SearchFoods(c)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), http.StatusOK, rec.Code)

	var response []*models.Food
	err = json.Unmarshal(rec.Body.Bytes(), &response)
	assert.NoError(suite.T(), err)
	assert.Len(suite.T(), response, 2)
	assert.Equal(suite.T(), expectedFoods[0].Name, response[0].Name)

	suite.mockService.AssertExpectations(suite.T())
}

// TestLogFoodHandler tests the LogFood handler
func (suite *HandlersTestSuite) TestLogFoodHandler() {
	// Setup mock
	suite.mockService.On("LogFood", 1, 1, 150.0, "breakfast").Return(nil)

	// Create request
	logData := map[string]interface{}{
		"user_id":   1,
		"food_id":   1,
		"quantity":  150.0,
		"meal_type": "breakfast",
	}
	logJSON, _ := json.Marshal(logData)
	req := httptest.NewRequest(http.MethodPost, "/food-logs", bytes.NewBuffer(logJSON))
	req.Header.Set(echo.HeaderContentType, echo.MIMEApplicationJSON)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)

	// Execute handler
	err := suite.handler.LogFood(c)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), http.StatusCreated, rec.Code)

	suite.mockService.AssertExpectations(suite.T())
}

// TestHealthCheckHandler tests the health check handler
func (suite *HandlersTestSuite) TestHealthCheckHandler() {
	// Create request
	req := httptest.NewRequest(http.MethodGet, "/health", nil)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)

	// Execute handler
	err := suite.handler.HealthCheck(c)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), http.StatusOK, rec.Code)

	var response map[string]interface{}
	err = json.Unmarshal(rec.Body.Bytes(), &response)
	assert.NoError(suite.T(), err)
	assert.Equal(suite.T(), "healthy", response["status"])
	assert.NotNil(suite.T(), response["timestamp"])
}

// TestGetUserHandlerNotFound tests GetUser with non-existent user
func (suite *HandlersTestSuite) TestGetUserHandlerNotFound() {
	// Setup mock to return error
	suite.mockService.On("GetUser", 999).Return((*models.User)(nil), assert.AnError)

	// Create request
	req := httptest.NewRequest(http.MethodGet, "/users/999", nil)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)
	c.SetParamNames("id")
	c.SetParamValues("999")

	// Execute handler
	err := suite.handler.GetUser(c)

	// Assertions
	assert.Error(suite.T(), err)

	suite.mockService.AssertExpectations(suite.T())
}

// TestInvalidParameterHandling tests handlers with invalid parameters
func (suite *HandlersTestSuite) TestInvalidParameterHandling() {
	// Test with invalid user ID
	req := httptest.NewRequest(http.MethodGet, "/users/invalid", nil)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)
	c.SetParamNames("id")
	c.SetParamValues("invalid")

	// Execute handler
	err := suite.handler.GetUser(c)

	// Assertions
	assert.Error(suite.T(), err)
}

// TestCORSHeaders tests CORS header handling
func (suite *HandlersTestSuite) TestCORSHeaders() {
	// Create request with Origin header
	req := httptest.NewRequest(http.MethodOptions, "/users", nil)
	req.Header.Set("Origin", "http://localhost:3000")
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)

	// Execute CORS middleware (if implemented)
	err := suite.handler.HandleCORS(c)

	// Assertions
	if err == nil {
		assert.Contains(suite.T(), rec.Header().Get("Access-Control-Allow-Origin"), "*")
	}
}

// TestRateLimitingHandler tests rate limiting functionality
func (suite *HandlersTestSuite) TestRateLimitingHandler() {
	// This test would require implementing rate limiting
	// For now, we'll test that the handler exists and can be called
	req := httptest.NewRequest(http.MethodGet, "/users/1", nil)
	rec := httptest.NewRecorder()
	c := suite.echo.NewContext(req, rec)

	// Test that multiple rapid requests don't cause issues
	for i := 0; i < 10; i++ {
		// Reset recorder for each iteration
		rec = httptest.NewRecorder()
		c = suite.echo.NewContext(req, rec)
		c.SetParamNames("id")
		c.SetParamValues("1")

		// This would trigger rate limiting in a real scenario
		// For testing, we just ensure no panic occurs
		assert.NotPanics(suite.T(), func() {
			suite.handler.GetUser(c)
		})
	}
}

// TestHandlersTestSuite runs the test suite
func TestHandlersTestSuite(t *testing.T) {
	suite.Run(t, new(HandlersTestSuite))
}

// BenchmarkGetUserHandler benchmarks the GetUser handler
func BenchmarkGetUserHandler(b *testing.B) {
	e := echo.New()
	mockService := new(MockService)
	handler := handlers.NewHandler(mockService)

	user := &models.User{
		ID:       1,
		Username: "testuser",
		Email:    "test@example.com",
	}
	mockService.On("GetUser", 1).Return(user, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		req := httptest.NewRequest(http.MethodGet, "/users/1", nil)
		rec := httptest.NewRecorder()
		c := e.NewContext(req, rec)
		c.SetParamNames("id")
		c.SetParamValues("1")

		handler.GetUser(c)
	}
}

// BenchmarkCreateUserHandler benchmarks the CreateUser handler
func BenchmarkCreateUserHandler(b *testing.B) {
	e := echo.New()
	mockService := new(MockService)
	handler := handlers.NewHandler(mockService)

	mockService.On("CreateUser", mock.AnythingOfType("*models.User")).Return(nil)

	user := &models.User{
		Username: "testuser",
		Email:    "test@example.com",
		Age:      25,
	}
	userJSON, _ := json.Marshal(user)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		req := httptest.NewRequest(http.MethodPost, "/users", bytes.NewBuffer(userJSON))
		req.Header.Set(echo.HeaderContentType, echo.MIMEApplicationJSON)
		rec := httptest.NewRecorder()
		c := e.NewContext(req, rec)

		handler.CreateUser(c)
	}
}
