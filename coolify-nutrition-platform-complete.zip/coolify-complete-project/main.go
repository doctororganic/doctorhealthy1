package main

import (
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"github.com/prometheus/client_golang/prometheus/promhttp"

	recipeAPI "nutrition-platform/api"
	"nutrition-platform/config"
	"nutrition-platform/handlers"
	middlewareCustom "nutrition-platform/middleware/custom"
	"nutrition-platform/models"
	"nutrition-platform/validation"

	// Add API key service import
	"nutrition-platform/services"
	// Import API key middleware with alias to avoid conflict
	apiKeyMiddleware "nutrition-platform/middleware"
)

func main() {
	// Load configuration
	cfg := config.Load()

	// Initialize database
	if err := models.InitDatabase(cfg); err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}
	defer models.CloseDatabase()

	// Initialize services
	apiKeyService := services.NewAPIKeyService(models.DB)
	analyticsService := services.NewAnalyticsService(models.DB)
	defer analyticsService.Stop()

	// Create Echo instance
	e := echo.New()

	// Set custom validator
	e.Validator = &validation.InputValidator{}

	// Initialize metrics
	metrics := middlewareCustom.NewMetrics()

	// Set custom error handler
	e.HTTPErrorHandler = middlewareCustom.ErrorHandler(cfg)

	// Middleware
	e.Use(middleware.Logger())
	e.Use(middleware.Recover())

	// CORS configuration for frontend integration
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins:     []string{"http://localhost:3000", "http://localhost:8080", "http://localhost", "https://super.doctorhealthy1.com"},
		AllowMethods:     []string{http.MethodGet, http.MethodPost, http.MethodPut, http.MethodDelete, http.MethodOptions},
		AllowHeaders:     []string{echo.HeaderOrigin, echo.HeaderContentType, echo.HeaderAccept, echo.HeaderAuthorization, "X-Requested-With"},
		AllowCredentials: true,
	}))

	e.Use(middleware.Gzip())
	e.Use(middlewareCustom.CorrelationID(cfg))
	e.Use(middlewareCustom.MetricsMiddleware(metrics))
	e.Use(middlewareCustom.SecurityHeaders(cfg))
	e.Use(middlewareCustom.RateLimiter(cfg))

	// Add request signing middleware for sensitive operations
	if cfg.IsProduction() {
		signingConfig := apiKeyMiddleware.DefaultRequestSigningConfig()
		signingConfig.SecretKey = cfg.APIKeySecret
		e.Use(apiKeyMiddleware.RequestSigningMiddleware(signingConfig))
	}

	// Health check endpoint (before circuit breaker to avoid being blocked)
	e.GET("/health", middlewareCustom.HealthCheck())

	// e.Use(middlewareCustom.CircuitBreakerMiddleware(cfg, metrics)) // Temporarily disabled
	e.Use(middlewareCustom.RequestSizeLimit(cfg.MaxRequestSize))

	// Metrics endpoint
	e.GET("/metrics", echo.WrapHandler(promhttp.Handler()))

	// Add non-versioned routes for frontend compatibility (before API key middleware)
	e.GET("/api/info", getAPIInfo)
	e.POST("/api/nutrition/analyze", analyzeNutrition)

	// API routes
	api := e.Group("/api/v1")

	// Apply API key middleware to all versioned API routes
	api.Use(apiKeyMiddleware.APIKeyMiddleware(apiKeyService))

	// Add signature verification for sensitive endpoints
	if cfg.IsProduction() {
		api.Use(apiKeyMiddleware.SignatureRequiredMiddleware())
	}

	// Add analytics middleware to track API usage
	api.Use(func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			start := time.Now()

			err := next(c)

			// Record analytics
			if apiKey := apiKeyMiddleware.GetAPIKeyFromContext(c); apiKey != nil {
				responseTime := time.Since(start).Milliseconds()
				statusCode := c.Response().Status

				go analyticsService.RecordAPIUsage(
					apiKey.ID,
					c.Request().URL.Path,
					c.Request().Method,
					statusCode,
					responseTime,
					c.RealIP(),
					c.Request().UserAgent(),
				)
			}

			return err
		}
	})

	// User routes
	api.GET("/users", getUsers)
	api.POST("/users", createUser)
	api.GET("/users/:id", getUser)
	api.PUT("/users/:id", updateUser)
	api.DELETE("/users/:id", deleteUser)

	// Food routes
	api.GET("/foods", getFoods)
	api.POST("/foods", createFood)
	api.GET("/foods/:id", getFood)
	api.PUT("/foods/:id", updateFood)
	api.DELETE("/foods/:id", deleteFood)
	api.GET("/foods/search", searchFoods)

	// Exercise routes
	api.GET("/exercises", getExercises)
	api.POST("/exercises", createExercise)
	api.GET("/exercises/:id", getExercise)
	api.PUT("/exercises/:id", updateExercise)
	api.DELETE("/exercises/:id", deleteExercise)
	api.GET("/exercises/search", searchExercises)

	// Non-versioned exercise routes for frontend integration
	e.GET("/exercises", getExercises)
	e.GET("/exercises/:id", getExercise)
	e.GET("/exercises/search", searchExercises)

	// Meal plan routes
	api.GET("/meal-plans", getMealPlans)
	api.POST("/meal-plans", createMealPlan)
	api.GET("/meal-plans/:id", getMealPlan)
	api.PUT("/meal-plans/:id", updateMealPlan)
	api.DELETE("/meal-plans/:id", deleteMealPlan)

	// Workout plan routes
	api.GET("/workout-plans", getWorkoutPlans)
	api.POST("/workout-plans", createWorkoutPlan)
	api.GET("/workout-plans/:id", getWorkoutPlan)
	api.PUT("/workout-plans/:id", updateWorkoutPlan)
	api.DELETE("/workout-plans/:id", deleteWorkoutPlan)

	// Food log routes
	api.GET("/food-logs", getFoodLogs)
	api.POST("/food-logs", createFoodLog)
	api.GET("/food-logs/:id", getFoodLog)
	api.PUT("/food-logs/:id", updateFoodLog)
	api.DELETE("/food-logs/:id", deleteFoodLog)

	// Exercise log routes
	api.GET("/exercise-logs", getExerciseLogs)
	api.POST("/exercise-logs", createExerciseLog)
	api.GET("/exercise-logs/:id", getExerciseLog)
	api.PUT("/exercise-logs/:id", updateExerciseLog)
	api.DELETE("/exercise-logs/:id", deleteExerciseLog)

	// Recipe routes
	recipeHandler := recipeAPI.NewRecipeHandler(cfg.DataPath)
	api.GET("/recipes", recipeHandler.GetRecipes)
	api.GET("/recipes/:id", recipeHandler.GetRecipeByID)
	api.GET("/recipes/country/:country", recipeHandler.GetRecipesByCountry)

	// Non-versioned recipe routes for frontend integration
	e.GET("/recipes", recipeHandler.GetRecipes)
	e.GET("/recipes/:id", recipeHandler.GetRecipeByID)
	e.GET("/recipes/country/:country", recipeHandler.GetRecipesByCountry)

	// Initialize and register nutrition data handler
	nutritionHandler := handlers.NewNutritionDataHandler(cfg.NutritionDataPath)
	nutritionHandler.RegisterRoutes(e)

	// Frontend integration routes
	api.GET("/info", getAPIInfo)
	api.POST("/nutrition/analyze", analyzeNutrition)

	// Meal plan generation endpoint (non-versioned for frontend compatibility)
	e.POST("/api/generate-meal-plan", generateMealPlan)

	// Additional generation endpoints for the four main features
	e.POST("/api/generate-workouts", generateWorkouts)
	e.POST("/api/generate-lifestyle-plan", generateLifestylePlan)
	e.POST("/api/generate-recipes", generateRecipes)

	// Initialize additional services
	recipeService := services.NewRecipeService(models.DB)
	healthService := services.NewHealthService(models.DB)
	nutritionPlanService := services.NewNutritionPlanService(models.DB)

	// API key management endpoints
	apiKeyHandler := handlers.NewAPIKeyHandler(apiKeyService, analyticsService)
	apiKeyHandler.RegisterRoutes(api)

	// Recipe management endpoints
	recipeHandler := handlers.NewRecipeHandler(recipeService)
	recipeHandler.RegisterRoutes(api)

	// Health management endpoints
	healthHandler := handlers.NewHealthHandler(healthService)
	healthHandler.RegisterRoutes(api)

	// Nutrition plan management endpoints
	nutritionPlanHandler := handlers.NewNutritionPlanHandler(nutritionPlanService, healthService)
	nutritionPlanHandler.RegisterRoutes(api)

	// Start server
	serverAddr := cfg.ServerHost + ":" + strconv.Itoa(cfg.ServerPort)
	log.Printf("Starting server on %s", serverAddr)

	server := &http.Server{
		Addr:         serverAddr,
		Handler:      e,
		ReadTimeout:  time.Duration(cfg.ReadTimeout) * time.Second,
		WriteTimeout: time.Duration(cfg.WriteTimeout) * time.Second,
		IdleTimeout:  time.Duration(cfg.KeepAliveTimeout) * time.Second,
	}

	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("Server failed to start: %v", err)
	}
}

// Placeholder handler functions

// User handlers
func getUsers(c echo.Context) error {
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get users endpoint",
		"data":    []interface{}{},
	})
}

func createUser(c echo.Context) error {
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"message": "User created successfully",
	})
}

func getUser(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get user endpoint",
		"id":      id,
	})
}

func updateUser(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "User updated successfully",
		"id":      id,
	})
}

func deleteUser(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "User deleted successfully",
		"id":      id,
	})
}

// Food handlers
func getFoods(c echo.Context) error {
	page, _ := strconv.Atoi(c.QueryParam("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(c.QueryParam("limit"))
	if limit < 1 || limit > 100 {
		limit = 20
	}

	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get foods endpoint",
		"data":    []interface{}{},
		"page":    page,
		"limit":   limit,
	})
}

func createFood(c echo.Context) error {
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"message": "Food created successfully",
	})
}

func getFood(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get food endpoint",
		"id":      id,
	})
}

func updateFood(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Food updated successfully",
		"id":      id,
	})
}

func deleteFood(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Food deleted successfully",
		"id":      id,
	})
}

func searchFoods(c echo.Context) error {
	query := c.QueryParam("q")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Search foods endpoint",
		"query":   query,
		"data":    []interface{}{},
	})
}

// Exercise handlers
func getExercises(c echo.Context) error {
	page, _ := strconv.Atoi(c.QueryParam("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(c.QueryParam("limit"))
	if limit < 1 || limit > 100 {
		limit = 20
	}

	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get exercises endpoint",
		"data":    []interface{}{},
		"page":    page,
		"limit":   limit,
	})
}

func createExercise(c echo.Context) error {
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"message": "Exercise created successfully",
	})
}

func getExercise(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get exercise endpoint",
		"id":      id,
	})
}

func updateExercise(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Exercise updated successfully",
		"id":      id,
	})
}

func deleteExercise(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Exercise deleted successfully",
		"id":      id,
	})
}

func searchExercises(c echo.Context) error {
	query := c.QueryParam("q")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Search exercises endpoint",
		"query":   query,
		"data":    []interface{}{},
	})
}

// Meal plan handlers
func getMealPlans(c echo.Context) error {
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get meal plans endpoint",
		"data":    []interface{}{},
	})
}

func createMealPlan(c echo.Context) error {
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"message": "Meal plan created successfully",
	})
}

func getMealPlan(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get meal plan endpoint",
		"id":      id,
	})
}

func updateMealPlan(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Meal plan updated successfully",
		"id":      id,
	})
}

func deleteMealPlan(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Meal plan deleted successfully",
		"id":      id,
	})
}

// Workout plan handlers
func getWorkoutPlans(c echo.Context) error {
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get workout plans endpoint",
		"data":    []interface{}{},
	})
}

func createWorkoutPlan(c echo.Context) error {
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"message": "Workout plan created successfully",
	})
}

func getWorkoutPlan(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get workout plan endpoint",
		"id":      id,
	})
}

func updateWorkoutPlan(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Workout plan updated successfully",
		"id":      id,
	})
}

func deleteWorkoutPlan(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Workout plan deleted successfully",
		"id":      id,
	})
}

// Food log handlers
func getFoodLogs(c echo.Context) error {
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get food logs endpoint",
		"data":    []interface{}{},
	})
}

func createFoodLog(c echo.Context) error {
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"message": "Food log created successfully",
	})
}

func getFoodLog(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get food log endpoint",
		"id":      id,
	})
}

func updateFoodLog(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Food log updated successfully",
		"id":      id,
	})
}

func deleteFoodLog(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Food log deleted successfully",
		"id":      id,
	})
}

// Exercise log handlers
func getExerciseLogs(c echo.Context) error {
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get exercise logs endpoint",
		"data":    []interface{}{},
	})
}

func createExerciseLog(c echo.Context) error {
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"message": "Exercise log created successfully",
	})
}

func getExerciseLog(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Get exercise log endpoint",
		"id":      id,
	})
}

func updateExerciseLog(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Exercise log updated successfully",
		"id":      id,
	})
}

func deleteExerciseLog(c echo.Context) error {
	id := c.Param("id")
	return c.JSON(http.StatusOK, map[string]interface{}{
		"message": "Exercise log deleted successfully",
		"id":      id,
	})
}

// Frontend integration endpoints
func getAPIInfo(c echo.Context) error {
	return c.JSON(http.StatusOK, map[string]interface{}{
		"name":        "Nutrition Platform API",
		"version":     "1.0.0",
		"description": "Doctor Healthy Nutrition Platform Backend API",
		"endpoints": []string{
			"/health",
			"/api/v1/info",
			"/api/v1/nutrition/analyze",
			"/api/v1/recipes",
			"/api/v1/foods",
			"/api/v1/exercises",
		},
		"features": []string{
			"Nutrition Analysis",
			"Halal Compliance Check",
			"Multi-language Support",
			"Recipe Management",
		},
		"status":    "online",
		"timestamp": time.Now().UTC(),
	})
}

type NutritionRequest struct {
	Food       string  `json:"food" validate:"required"`
	Quantity   float64 `json:"quantity" validate:"required,min=0"`
	Unit       string  `json:"unit" validate:"required"`
	CheckHalal bool    `json:"checkHalal"`
	Language   string  `json:"language"`
}

type NutritionResponse struct {
	Food              string   `json:"food"`
	Quantity          float64  `json:"quantity"`
	Unit              string   `json:"unit"`
	Calories          int      `json:"calories"`
	Protein           float64  `json:"protein"`
	Carbohydrates     float64  `json:"carbohydrates"`
	Fat               float64  `json:"fat"`
	Fiber             float64  `json:"fiber"`
	HalalStatus       *bool    `json:"halalStatus,omitempty"`
	Recommendations   []string `json:"recommendations"`
	MedicalDisclaimer string   `json:"medicalDisclaimer"`
}

func analyzeNutrition(c echo.Context) error {
	var req NutritionRequest
	if err := c.Bind(&req); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "Invalid request format"})
	}

	if err := c.Validate(&req); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": err.Error()})
	}

	// Generate nutrition analysis (mock implementation)
	response := generateNutritionAnalysis(req)

	return c.JSON(http.StatusOK, response)
}

func generateNutritionAnalysis(req NutritionRequest) NutritionResponse {
	// Mock nutrition data based on common foods
	baseNutrition := map[string]map[string]float64{
		"chicken": {"calories": 165, "protein": 31, "carbs": 0, "fat": 3.6, "fiber": 0},
		"rice":    {"calories": 130, "protein": 2.7, "carbs": 28, "fat": 0.3, "fiber": 0.4},
		"apple":   {"calories": 52, "protein": 0.3, "carbs": 14, "fat": 0.2, "fiber": 2.4},
		"bread":   {"calories": 265, "protein": 9, "carbs": 49, "fat": 3.2, "fiber": 2.7},
		"egg":     {"calories": 155, "protein": 13, "carbs": 1.1, "fat": 11, "fiber": 0},
		"milk":    {"calories": 42, "protein": 3.4, "carbs": 5, "fat": 1, "fiber": 0},
		"fish":    {"calories": 206, "protein": 22, "carbs": 0, "fat": 12, "fiber": 0},
	}

	// Default values
	nutrition := map[string]float64{"calories": 100, "protein": 5, "carbs": 15, "fat": 3, "fiber": 2}

	// Find matching food
	foodLower := strings.ToLower(req.Food)
	for food, values := range baseNutrition {
		if strings.Contains(foodLower, food) {
			nutrition = values
			break
		}
	}

	// Scale by quantity (assuming per 100g base)
	scale := req.Quantity / 100

	// Check halal status if requested
	var halalStatus *bool
	if req.CheckHalal {
		isHalal := checkHalalStatus(req.Food)
		halalStatus = &isHalal
	}

	// Generate recommendations
	recommendations := generateRecommendations(req.Food, nutrition)

	return NutritionResponse{
		Food:              req.Food,
		Quantity:          req.Quantity,
		Unit:              req.Unit,
		Calories:          int(nutrition["calories"] * scale),
		Protein:           nutrition["protein"] * scale,
		Carbohydrates:     nutrition["carbs"] * scale,
		Fat:               nutrition["fat"] * scale,
		Fiber:             nutrition["fiber"] * scale,
		HalalStatus:       halalStatus,
		Recommendations:   recommendations,
		MedicalDisclaimer: "This nutritional information is for educational purposes only and should not replace professional medical advice. Consult with a healthcare provider for personalized dietary recommendations.",
	}
}

func checkHalalStatus(food string) bool {
	nonHalalKeywords := []string{"pork", "ham", "bacon", "wine", "beer", "alcohol", "gelatin"}
	foodLower := strings.ToLower(food)

	for _, keyword := range nonHalalKeywords {
		if strings.Contains(foodLower, keyword) {
			return false
		}
	}
	return true
}

func generateRecommendations(food string, nutrition map[string]float64) []string {
	recommendations := []string{
		"Maintain a balanced diet with variety of foods",
		"Consider portion sizes appropriate for your daily needs",
	}

	// Add specific recommendations based on nutrition profile
	if nutrition["protein"] > 20 {
		recommendations = append(recommendations, "Excellent source of protein for muscle health")
	}
	if nutrition["fiber"] > 3 {
		recommendations = append(recommendations, "Good source of fiber for digestive health")
	}
	if nutrition["calories"] > 200 {
		recommendations = append(recommendations, "High calorie food - consider portion control")
	}

	return recommendations
}

// MealPlanRequest represents the request structure for meal plan generation
type MealPlanRequest struct {
	Age                 int      `json:"age"`
	Gender              string   `json:"gender"`
	Height              float64  `json:"height"`
	Weight              float64  `json:"weight"`
	ActivityLevel       string   `json:"activityLevel"`
	Goal                string   `json:"goal"`
	DietaryRestrictions []string `json:"dietaryRestrictions"`
	Allergies           []string `json:"allergies"`
	Preferences         []string `json:"preferences"`
	HealthConditions    []string `json:"healthConditions"`
}

// generateMealPlan handles meal plan generation requests
func generateMealPlan(c echo.Context) error {
	var req MealPlanRequest
	if err := c.Bind(&req); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]interface{}{
			"error": "Invalid request format",
		})
	}

	// Create a temporary user profile for meal plan generation
	profile := &services.UserProfile{
		Age:                 req.Age,
		Gender:              req.Gender,
		Height:              req.Height,
		Weight:              req.Weight,
		ActivityLevel:       req.ActivityLevel,
		Goal:                req.Goal,
		DietaryRestrictions: req.DietaryRestrictions,
		Allergies:           req.Allergies,
		Preferences:         req.Preferences,
		HealthConditions:    req.HealthConditions,
	}

	// Calculate BMR and TDEE
	bmr := calculateBMR(req.Age, req.Gender, req.Height, req.Weight)
	tdee := calculateTDEE(bmr, req.ActivityLevel)
	targetCalories := calculateTargetCalories(tdee, req.Goal)

	// Calculate macro breakdown
	protein, carbs, fat := calculateMacroTargets(targetCalories, req.Goal, req.Weight)
	macros := services.MacroBreakdown{
		Protein:    protein,
		Carbs:      carbs,
		Fat:        fat,
		ProteinPct: (protein * 4) / targetCalories * 100,
		CarbsPct:   (carbs * 4) / targetCalories * 100,
		FatPct:     (fat * 9) / targetCalories * 100,
	}

	// Generate meal plan
	mealPlan := generateSimpleMealPlan(profile, targetCalories, macros)

	response := map[string]interface{}{
		"success":        true,
		"targetCalories": targetCalories,
		"macroBreakdown": macros,
		"mealPlan":       mealPlan,
		"bmr":            bmr,
		"tdee":           tdee,
		"generatedAt":    time.Now(),
	}

	return c.JSON(http.StatusOK, response)
}

// Helper functions for meal plan generation
func calculateBMR(age int, gender string, height, weight float64) float64 {
	if gender == "male" {
		return 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * float64(age))
	}
	return 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * float64(age))
}

func calculateTDEE(bmr float64, activityLevel string) float64 {
	multipliers := map[string]float64{
		"sedentary":   1.2,
		"light":       1.375,
		"moderate":    1.55,
		"active":      1.725,
		"very_active": 1.9,
	}

	if multiplier, exists := multipliers[activityLevel]; exists {
		return bmr * multiplier
	}
	return bmr * 1.55 // default to moderate
}

func calculateTargetCalories(tdee float64, goal string) float64 {
	switch goal {
	case "lose":
		return tdee - 500 // 1 lb per week loss
	case "gain":
		return tdee + 500 // 1 lb per week gain
	default:
		return tdee // maintain
	}
}

func calculateMacroTargets(calories float64, goal string, weight float64) (protein, carbs, fat float64) {
	// Protein: 1.6-2.2g per kg body weight
	protein = weight * 1.8

	// Fat: 20-35% of calories
	fatCalories := calories * 0.25
	fat = fatCalories / 9

	// Carbs: remaining calories
	remainingCalories := calories - (protein * 4) - (fat * 9)
	carbs = remainingCalories / 4

	return protein, carbs, fat
}

func generateSimpleMealPlan(profile *services.UserProfile, calories float64, macros services.MacroBreakdown) []services.MealRecommendation {
	mealPlan := make([]services.MealRecommendation, 0)

	// Distribute calories across meals
	breakfastCals := calories * 0.25
	lunchCals := calories * 0.35
	dinnerCals := calories * 0.30
	snackCals := calories * 0.10

	mealPlan = append(mealPlan, services.MealRecommendation{
		MealType: "breakfast",
		Calories: breakfastCals,
		Foods:    suggestFoodsForMeal("breakfast", profile),
		Timing:   "7:00-9:00 AM",
		Priority: 1,
	})

	mealPlan = append(mealPlan, services.MealRecommendation{
		MealType: "lunch",
		Calories: lunchCals,
		Foods:    suggestFoodsForMeal("lunch", profile),
		Timing:   "12:00-2:00 PM",
		Priority: 1,
	})

	mealPlan = append(mealPlan, services.MealRecommendation{
		MealType: "dinner",
		Calories: dinnerCals,
		Foods:    suggestFoodsForMeal("dinner", profile),
		Timing:   "6:00-8:00 PM",
		Priority: 1,
	})

	mealPlan = append(mealPlan, services.MealRecommendation{
		MealType: "snack",
		Calories: snackCals,
		Foods:    suggestFoodsForMeal("snack", profile),
		Timing:   "3:00-4:00 PM",
		Priority: 2,
	})

	return mealPlan
}

func suggestFoodsForMeal(mealType string, profile *services.UserProfile) []string {
	foods := make([]string, 0)

	// Basic food suggestions based on meal type
	switch mealType {
	case "breakfast":
		foods = []string{"Oatmeal with berries", "Greek yogurt with nuts", "Whole grain toast with avocado"}
	case "lunch":
		foods = []string{"Grilled chicken salad", "Quinoa bowl with vegetables", "Lentil soup with whole grain bread"}
	case "dinner":
		foods = []string{"Baked salmon with sweet potato", "Lean beef with brown rice", "Tofu stir-fry with vegetables"}
	case "snack":
		foods = []string{"Apple with almond butter", "Mixed nuts", "Greek yogurt"}
	}

	// Filter based on dietary restrictions
	if profile != nil && len(profile.DietaryRestrictions) > 0 {
		filteredFoods := make([]string, 0)
		for _, food := range foods {
			if isFoodAllowed(food, profile.DietaryRestrictions) {
				filteredFoods = append(filteredFoods, food)
			}
		}
		if len(filteredFoods) > 0 {
			foods = filteredFoods
		}
	}

	return foods
}

func isFoodAllowed(food string, restrictions []string) bool {
	food = strings.ToLower(food)
	for _, restriction := range restrictions {
		restriction = strings.ToLower(restriction)
		switch restriction {
		case "vegetarian":
			if strings.Contains(food, "meat") || strings.Contains(food, "chicken") ||
				strings.Contains(food, "beef") || strings.Contains(food, "pork") ||
				strings.Contains(food, "fish") || strings.Contains(food, "seafood") {
				return false
			}
		case "vegan":
			if strings.Contains(food, "meat") || strings.Contains(food, "chicken") ||
				strings.Contains(food, "beef") || strings.Contains(food, "pork") ||
				strings.Contains(food, "fish") || strings.Contains(food, "seafood") ||
				strings.Contains(food, "dairy") || strings.Contains(food, "milk") ||
				strings.Contains(food, "cheese") || strings.Contains(food, "egg") {
				return false
			}
		case "gluten-free":
			if strings.Contains(food, "wheat") || strings.Contains(food, "bread") ||
				strings.Contains(food, "pasta") || strings.Contains(food, "flour") {
				return false
			}
		}
	}
	return true
}

// Workout generation request and response types
type WorkoutRequest struct {
	Age           int      `json:"age"`
	Gender        string   `json:"gender"`
	FitnessLevel  string   `json:"fitnessLevel"`
	Goals         []string `json:"goals"`
	AvailableTime int      `json:"availableTime"`
	Equipment     []string `json:"equipment"`
	Injuries      []string `json:"injuries"`
	Preferences   []string `json:"preferences"`
	Language      string   `json:"language"`
}

type WorkoutResponse struct {
	WeeklyPlan     []DayWorkout `json:"weeklyPlan"`
	NutritionTips  []string     `json:"nutritionTips"`
	WarmupTips     []string     `json:"warmupTips"`
	SupplementTips []string     `json:"supplementTips"`
	InjuryGuidance []string     `json:"injuryGuidance"`
	Language       string       `json:"language"`
}

type DayWorkout struct {
	Day       string     `json:"day"`
	Exercises []Exercise `json:"exercises"`
	Duration  int        `json:"duration"`
}

type Exercise struct {
	Name           string   `json:"name"`
	Sets           int      `json:"sets"`
	Reps           string   `json:"reps"`
	Rest           string   `json:"rest"`
	Instructions   string   `json:"instructions"`
	CommonMistakes []string `json:"commonMistakes"`
	Modifications  []string `json:"modifications"`
}

// Lifestyle plan request and response types
type LifestylePlanRequest struct {
	Age              int      `json:"age"`
	Gender           string   `json:"gender"`
	HealthConditions []string `json:"healthConditions"`
	Symptoms         []string `json:"symptoms"`
	CurrentMeds      []string `json:"currentMeds"`
	Lifestyle        string   `json:"lifestyle"`
	Language         string   `json:"language"`
}

type LifestylePlanResponse struct {
	TreatmentPlan     []TreatmentStep `json:"treatmentPlan"`
	NutritionPlan     []string        `json:"nutritionPlan"`
	LifestyleChanges  []string        `json:"lifestyleChanges"`
	SupplementPlan    []Supplement    `json:"supplementPlan"`
	MonitoringTips    []string        `json:"monitoringTips"`
	MedicalDisclaimer string          `json:"medicalDisclaimer"`
	Language          string          `json:"language"`
}

type TreatmentStep struct {
	Step        string `json:"step"`
	Description string `json:"description"`
	Timeline    string `json:"timeline"`
}

type Supplement struct {
	Name     string `json:"name"`
	Dosage   string `json:"dosage"`
	Timing   string `json:"timing"`
	Benefits string `json:"benefits"`
}

// Recipe generation request and response types
type RecipeRequest struct {
	PreferredCuisines []string `json:"preferredCuisines"`
	CookingSkill      string   `json:"cookingSkill"`
	CookingTime       int      `json:"cookingTime"`
	MealType          string   `json:"mealType"`
	FoodDislikes      string   `json:"foodDislikes"`
	Allergies         string   `json:"allergies"`
	DietType          string   `json:"dietType"`
	Servings          int      `json:"servings"`
	Language          string   `json:"language"`
}

type RecipeResponse struct {
	Recipes         []Recipe     `json:"recipes"`
	CookingTips     []CookingTip `json:"cookingTips"`
	EnhancementTips []CookingTip `json:"enhancementTips"`
	Language        string       `json:"language"`
}

type Recipe struct {
	Name          string        `json:"name"`
	Cuisine       string        `json:"cuisine"`
	Difficulty    string        `json:"difficulty"`
	CookingTime   string        `json:"cookingTime"`
	Servings      int           `json:"servings"`
	Ingredients   []string      `json:"ingredients"`
	Instructions  []string      `json:"instructions"`
	NutritionInfo NutritionInfo `json:"nutritionInfo"`
}

type CookingTip struct {
	Title string `json:"title"`
	Tip   string `json:"tip"`
}

type NutritionInfo struct {
	Calories int    `json:"calories"`
	Protein  string `json:"protein"`
	Carbs    string `json:"carbs"`
	Fat      string `json:"fat"`
}

// Generate workouts endpoint
func generateWorkouts(c echo.Context) error {
	var req WorkoutRequest
	if err := c.Bind(&req); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "Invalid request format"})
	}

	// Generate workout plan based on request
	response := WorkoutResponse{
		WeeklyPlan: []DayWorkout{
			{
				Day:      "Monday",
				Duration: req.AvailableTime,
				Exercises: []Exercise{
					{
						Name:           "Push-ups",
						Sets:           3,
						Reps:           "8-12",
						Rest:           "60 seconds",
						Instructions:   "Keep your body straight, lower chest to ground, push back up",
						CommonMistakes: []string{"Sagging hips", "Incomplete range of motion"},
						Modifications:  []string{"Knee push-ups for beginners", "Incline push-ups"},
					},
				},
			},
		},
		NutritionTips: []string{
			"Consume protein within 30 minutes post-workout",
			"Stay hydrated throughout your workout",
		},
		WarmupTips: []string{
			"Always start with 5-10 minutes of light cardio",
			"Include dynamic stretches before lifting",
		},
		SupplementTips: []string{
			"Consider whey protein for muscle recovery",
			"Creatine can help with strength gains",
		},
		InjuryGuidance: []string{
			"Stop immediately if you feel sharp pain",
			"Ice injuries within 24 hours",
		},
		Language: req.Language,
	}

	return c.JSON(http.StatusOK, response)
}

// Generate lifestyle plan endpoint
func generateLifestylePlan(c echo.Context) error {
	var req LifestylePlanRequest
	if err := c.Bind(&req); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "Invalid request format"})
	}

	// Generate lifestyle plan based on request
	response := LifestylePlanResponse{
		TreatmentPlan: []TreatmentStep{
			{
				Step:        "Initial Assessment",
				Description: "Complete medical evaluation and baseline measurements",
				Timeline:    "Week 1",
			},
			{
				Step:        "Lifestyle Modifications",
				Description: "Implement dietary changes and exercise routine",
				Timeline:    "Weeks 2-4",
			},
		},
		NutritionPlan: []string{
			"Increase fiber intake to 25-30g daily",
			"Reduce processed food consumption",
			"Include omega-3 rich foods 2-3 times per week",
		},
		LifestyleChanges: []string{
			"Establish regular sleep schedule (7-9 hours)",
			"Practice stress management techniques",
			"Increase daily physical activity",
		},
		SupplementPlan: []Supplement{
			{
				Name:     "Vitamin D3",
				Dosage:   "1000-2000 IU",
				Timing:   "With breakfast",
				Benefits: "Supports immune function and bone health",
			},
		},
		MonitoringTips: []string{
			"Track symptoms daily in a journal",
			"Monitor blood pressure weekly",
			"Schedule regular check-ups with healthcare provider",
		},
		MedicalDisclaimer: "This information is for educational purposes only and should not replace professional medical advice. Always consult with a healthcare provider before making significant changes to your health regimen.",
		Language:          req.Language,
	}

	return c.JSON(http.StatusOK, response)
}

// Generate recipes endpoint
func generateRecipes(c echo.Context) error {
	var req RecipeRequest
	if err := c.Bind(&req); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "Invalid request format"})
	}

	// Generate recipes based on request
	response := RecipeResponse{
		Recipes: []Recipe{
			{
				Name:        "Mediterranean Quinoa Bowl",
				Cuisine:     "Mediterranean",
				Difficulty:  req.CookingSkill,
				CookingTime: strconv.Itoa(req.CookingTime) + " minutes",
				Servings:    req.Servings,
				Ingredients: []string{
					"1 cup quinoa",
					"2 cups vegetable broth",
					"1 cucumber, diced",
					"2 tomatoes, chopped",
					"1/4 cup olive oil",
					"2 tbsp lemon juice",
				},
				Instructions: []string{
					"Rinse quinoa under cold water",
					"Bring vegetable broth to boil, add quinoa",
					"Simmer for 15 minutes until tender",
					"Mix vegetables with olive oil and lemon juice",
					"Combine quinoa with vegetable mixture",
					"Season with salt and pepper to taste",
				},
				NutritionInfo: NutritionInfo{
					Calories: 320,
					Protein:  "12g",
					Carbs:    "45g",
					Fat:      "12g",
				},
			},
		},
		CookingTips: []CookingTip{
			{
				Title: "Perfect Quinoa",
				Tip:   "Always rinse quinoa before cooking to remove bitter coating",
			},
		},
		EnhancementTips: []CookingTip{
			{
				Title: "Flavor Boost",
				Tip:   "Toast quinoa in a dry pan for 2-3 minutes before adding liquid for nuttier flavor",
			},
		},
		Language: req.Language,
	}

	return c.JSON(http.StatusOK, response)
}
