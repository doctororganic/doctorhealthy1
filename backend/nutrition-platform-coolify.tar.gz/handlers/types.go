package handlers

type Handler struct{}

func NewHandler() *Handler {
	return &Handler{}
}
