# Coolify MCP Server

This is an MCP (Model Context Protocol) server that provides tools for interacting with the Coolify API.

## Features

- List projects
- Get project details
- Deploy projects
- List deployments
- Get deployment details
- List servers
- Get server details

## Environment Variables

- `COOLIFY_API_TOKEN`: Your Coolify API token (required)
- `COOLIFY_API_BASE_URL`: The base URL for your Coolify API (default: https://api.doctorhealthy1.com/api/v1)

## Building

```bash
npm install
npm run build
```

## Running

The server is configured to run via MCP in your IDE extensions.

## Tools

### list_projects
Lists projects with optional pagination.

### get_project
Gets details of a specific project by ID.

### deploy_project
Initiates a deployment for a project.

### list_deployments
Lists deployments, optionally filtered by project.

### get_deployment
Gets details of a specific deployment.

### list_servers
Lists servers with optional pagination.

### get_server
Gets details of a specific server.