package main

import (
	"log"
	"net/http"
	"os"
	"nutrition-platform/handlers"
	"nutrition-platform/models"
	
	"github.com/gorilla/mux"
)

func main() {
	// Initialize database
	if err := models.InitDatabase(nil); err != nil {
		log.Fatal("Failed to initialize database:", err)
	}
	defer models.CloseDatabase()
	
	// Create router
	r := mux.NewRouter()
	
	// Initialize handlers
	h := handlers.NewHandler()
	
	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","uptime":"running"}`))
	}).Methods("GET")
	
	// API routes
	api := r.PathPrefix("/api/v1").Subrouter()
	api.HandleFunc("/users", h.GetUsers).Methods("GET")
	api.HandleFunc("/foods", h.GetFoods).Methods("GET")
	api.HandleFunc("/workouts", h.GetWorkouts).Methods("GET")
	api.HandleFunc("/recipes", h.GetRecipes).Methods("GET")
	
	// Start server
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	
	log.Printf("Server starting on port %s...", port)
	if err := http.ListenAndServe(":"+port, r); err != nil {
		log.Fatal("Server failed:", err)
	}
}
