package services

type LogService struct{}

func NewLogService() *LogService {
	return &LogService{}
}
