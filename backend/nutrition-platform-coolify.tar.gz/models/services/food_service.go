package services

type FoodService struct{}

func NewFoodService() *FoodService {
	return &FoodService{}
}
