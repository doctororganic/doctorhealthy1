package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

// Configuration
type Config struct {
	Port        string
	Environment string
	Domain      string
}

// Health Response
type HealthResponse struct {
	Status    string    `json:"status"`
	Timestamp time.Time `json:"timestamp"`
	Message   string    `json:"message"`
	Version   string    `json:"version"`
	Uptime    string    `json:"uptime"`
}

// Nutrition Request
type NutritionRequest struct {
	Food       string  `json:"food" binding:"required"`
	Quantity   float64 `json:"quantity" binding:"required,min=0"`
	Unit       string  `json:"unit" binding:"required"`
	CheckHalal bool    `json:"checkHalal"`
}

// Nutrition Response
type NutritionResponse struct {
	Food      string    `json:"food"`
	Quantity  float64   `json:"quantity"`
	Unit      string    `json:"unit"`
	Calories  float64   `json:"calories"`
	Protein   float64   `json:"protein"`
	Carbs     float64   `json:"carbs"`
	Fat       float64   `json:"fat"`
	Fiber     float64   `json:"fiber"`
	Sugar     float64   `json:"sugar"`
	Sodium    float64   `json:"sodium"`
	Calcium   float64   `json:"calcium"`
	Iron      float64   `json:"iron"`
	VitaminC  float64   `json:"vitaminC"`
	IsHalal   bool      `json:"isHalal"`
	Status    string    `json:"status"`
	Message   string    `json:"message"`
	Timestamp time.Time `json:"timestamp"`
}

// API Info Response
type APIInfo struct {
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Version     string            `json:"version"`
	Status      string            `json:"status"`
	Endpoints   map[string]string `json:"endpoints"`
	Features    []string          `json:"features"`
	Timestamp   time.Time         `json:"timestamp"`
}

// Diet Plan
type DietPlan struct {
	ID           int      `json:"id"`
	Name         string   `json:"name"`
	Description  string   `json:"description"`
	Type         string   `json:"type"`
	Duration     string   `json:"duration"`
	Benefits     []string `json:"benefits"`
	Foods        []string `json:"foods"`
	Restrictions []string `json:"restrictions"`
}

// Recipe
type Recipe struct {
	ID           int      `json:"id"`
	Name         string   `json:"name"`
	Description  string   `json:"description"`
	Ingredients  []string `json:"ingredients"`
	Instructions []string `json:"instructions"`
	PrepTime     int      `json:"prepTime"`
	CookTime     int      `json:"cookTime"`
	Servings     int      `json:"servings"`
	Calories     float64  `json:"calories"`
	IsHalal      bool     `json:"isHalal"`
	Category     string   `json:"category"`
}

var (
	startTime = time.Now()
	config    Config
)

// Comprehensive nutrition database
var nutritionDB = map[string]map[string]float64{
	"apple": {
		"calories": 52, "protein": 0.3, "carbs": 14, "fat": 0.2,
		"fiber": 2.4, "sugar": 10.4, "sodium": 1, "calcium": 6, "iron": 0.12, "vitaminC": 4.6,
	},
	"banana": {
		"calories": 89, "protein": 1.1, "carbs": 23, "fat": 0.3,
		"fiber": 2.6, "sugar": 12.2, "sodium": 1, "calcium": 5, "iron": 0.26, "vitaminC": 8.7,
	},
	"chicken": {
		"calories": 165, "protein": 31, "carbs": 0, "fat": 3.6,
		"fiber": 0, "sugar": 0, "sodium": 74, "calcium": 11, "iron": 0.9, "vitaminC": 0,
	},
	"rice": {
		"calories": 130, "protein": 2.7, "carbs": 28, "fat": 0.3,
		"fiber": 0.4, "sugar": 0.1, "sodium": 5, "calcium": 28, "iron": 0.8, "vitaminC": 0,
	},
	"bread": {
		"calories": 265, "protein": 9, "carbs": 49, "fat": 3.2,
		"fiber": 2.7, "sugar": 5.7, "sodium": 491, "calcium": 177, "iron": 3.6, "vitaminC": 0,
	},
	"egg": {
		"calories": 155, "protein": 13, "carbs": 1.1, "fat": 11,
		"fiber": 0, "sugar": 1.1, "sodium": 124, "calcium": 56, "iron": 1.75, "vitaminC": 0,
	},
	"milk": {
		"calories": 42, "protein": 3.4, "carbs": 5, "fat": 1,
		"fiber": 0, "sugar": 5, "sodium": 44, "calcium": 113, "iron": 0.03, "vitaminC": 0,
	},
	"orange": {
		"calories": 47, "protein": 0.9, "carbs": 12, "fat": 0.1,
		"fiber": 2.4, "sugar": 9.4, "sodium": 0, "calcium": 40, "iron": 0.1, "vitaminC": 53.2,
	},
	"salmon": {
		"calories": 208, "protein": 25.4, "carbs": 0, "fat": 12.4,
		"fiber": 0, "sugar": 0, "sodium": 59, "calcium": 9, "iron": 0.3, "vitaminC": 0,
	},
	"broccoli": {
		"calories": 34, "protein": 2.8, "carbs": 7, "fat": 0.4,
		"fiber": 2.6, "sugar": 1.5, "sodium": 33, "calcium": 47, "iron": 0.73, "vitaminC": 89.2,
	},
}

// Halal foods database
var halalFoods = map[string]bool{
	"apple": true, "banana": true, "orange": true, "rice": true,
	"bread": true, "egg": true, "milk": true, "chicken": true,
	"beef": true, "fish": true, "salmon": true, "broccoli": true,
	"vegetables": true, "fruits": true, "nuts": true, "beans": true,
}

// Diet plans database
var dietPlans = []DietPlan{
	{
		ID: 1, Name: "Mediterranean Diet", Type: "Heart-Healthy",
		Description:  "A heart-healthy eating plan based on the traditional dietary patterns of countries bordering the Mediterranean Sea.",
		Duration:     "Long-term lifestyle",
		Benefits:     []string{"Heart health", "Brain function", "Weight management", "Diabetes prevention"},
		Foods:        []string{"Olive oil", "Fish", "Vegetables", "Fruits", "Whole grains", "Nuts"},
		Restrictions: []string{"Processed foods", "Red meat", "Refined sugars"},
	},
	{
		ID: 2, Name: "DASH Diet", Type: "Blood Pressure",
		Description:  "Dietary Approaches to Stop Hypertension - designed to help treat or prevent high blood pressure.",
		Duration:     "Long-term lifestyle",
		Benefits:     []string{"Lower blood pressure", "Heart health", "Weight loss", "Kidney health"},
		Foods:        []string{"Fruits", "Vegetables", "Whole grains", "Lean proteins", "Low-fat dairy"},
		Restrictions: []string{"High sodium foods", "Processed meats", "Sugary drinks"},
	},
	{
		ID: 3, Name: "Ketogenic Diet", Type: "Low-Carb",
		Description:  "A very low-carb, high-fat diet that can help with weight loss and certain health conditions.",
		Duration:     "3-6 months",
		Benefits:     []string{"Rapid weight loss", "Mental clarity", "Blood sugar control", "Epilepsy management"},
		Foods:        []string{"Meat", "Fish", "Eggs", "Cheese", "Oils", "Low-carb vegetables"},
		Restrictions: []string{"Grains", "Sugar", "Most fruits", "Legumes"},
	},
}

// Sample recipes
var recipes = []Recipe{
	{
		ID: 1, Name: "Grilled Chicken Salad", Category: "Main Course",
		Description:  "A healthy and delicious grilled chicken salad with mixed greens",
		Ingredients:  []string{"Chicken breast", "Mixed greens", "Tomatoes", "Cucumber", "Olive oil", "Lemon"},
		Instructions: []string{"Grill chicken breast", "Prepare vegetables", "Mix salad", "Add dressing"},
		PrepTime:     15, CookTime: 20, Servings: 2, Calories: 350, IsHalal: true,
	},
	{
		ID: 2, Name: "Salmon with Broccoli", Category: "Main Course",
		Description:  "Baked salmon with steamed broccoli - rich in omega-3 and vitamins",
		Ingredients:  []string{"Salmon fillet", "Broccoli", "Olive oil", "Garlic", "Lemon", "Herbs"},
		Instructions: []string{"Preheat oven", "Season salmon", "Steam broccoli", "Bake salmon", "Serve together"},
		PrepTime:     10, CookTime: 25, Servings: 2, Calories: 420, IsHalal: true,
	},
}

func loadConfig() {
	config = Config{
		Port:        getEnv("PORT", "8080"),
		Environment: getEnv("ENVIRONMENT", "production"),
		Domain:      getEnv("DOMAIN", "super.doctorhealthy1.com"),
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func setupRouter() *gin.Engine {
	if config.Environment == "production" {
		gin.SetMode(gin.ReleaseMode)
	}

	r := gin.Default()

	// CORS middleware
	r.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	})

	// Routes
	r.GET("/", homepageHandler)
	r.GET("/health", healthHandler)
	r.GET("/api/info", apiInfoHandler)
	r.POST("/api/nutrition/analyze", nutritionAnalysisHandler)
	r.GET("/api/diet-plans", dietPlansHandler)
	r.GET("/api/diet-plans/:id", dietPlanHandler)
	r.GET("/api/recipes", recipesHandler)
	r.GET("/api/recipes/:id", recipeHandler)

	return r
}

func homepageHandler(c *gin.Context) {
	html := `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trae New Healthy1 - AI Nutrition Platform</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; color: #333;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; color: white; margin-bottom: 40px; }
        .header h1 { font-size: 3em; margin-bottom: 10px; text-shadow: 2px 2px 4px rgba(0,0,0,0.3); }
        .main-content { background: white; border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
        .status-badge { background: #27ae60; color: white; padding: 15px 30px; border-radius: 50px; text-align: center; font-size: 1.1em; font-weight: bold; margin-bottom: 30px; }
        .features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 30px 0; }
        .feature-card { background: #f8f9fa; padding: 25px; border-radius: 15px; border-left: 5px solid #3498db; transition: transform 0.3s ease; }
        .feature-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .feature-card h3 { color: #2c3e50; margin-bottom: 10px; font-size: 1.2em; }
        .endpoints { background: #2c3e50; color: white; padding: 30px; border-radius: 15px; margin: 30px 0; }
        .endpoint { background: #34495e; padding: 15px; margin: 10px 0; border-radius: 8px; font-family: 'Courier New', monospace; border-left: 4px solid #3498db; }
        .test-section { background: #ecf0f1; padding: 30px; border-radius: 15px; margin: 30px 0; }
        .test-form { display: grid; gap: 15px; max-width: 500px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { margin-bottom: 5px; font-weight: bold; color: #2c3e50; }
        .form-group input, .form-group select { padding: 12px; border: 2px solid #bdc3c7; border-radius: 8px; font-size: 16px; }
        .test-button { background: #3498db; color: white; padding: 15px 30px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; }
        .test-button:hover { background: #2980b9; }
        .result { margin-top: 20px; padding: 20px; background: white; border-radius: 8px; border-left: 4px solid #27ae60; }
        .footer { text-align: center; color: white; margin-top: 40px; opacity: 0.8; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🍎 Trae New Healthy1</h1>
            <p>AI-Powered Nutrition & Health Management Platform</p>
        </div>
        
        <div class="main-content">
            <div class="status-badge">✅ Platform is LIVE and Ready to Use!</div>
            
            <h2>🎯 Platform Features</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <h3>🧠 AI Nutrition Analysis</h3>
                    <p>Advanced algorithms analyze food nutritional content with precision</p>
                </div>
                <div class="feature-card">
                    <h3>🕌 Halal Verification</h3>
                    <p>Automatic halal food verification for religious dietary compliance</p>
                </div>
                <div class="feature-card">
                    <h3>📊 Comprehensive Data</h3>
                    <p>Complete nutritional breakdown including vitamins and minerals</p>
                </div>
                <div class="feature-card">
                    <h3>🍽️ Diet Plans</h3>
                    <p>Evidence-based diet plans for various health goals</p>
                </div>
                <div class="feature-card">
                    <h3>👨‍🍳 Recipe Database</h3>
                    <p>Healthy recipes with nutritional information</p>
                </div>
                <div class="feature-card">
                    <h3>📱 API Integration</h3>
                    <p>RESTful API for seamless integration</p>
                </div>
            </div>
            
            <div class="endpoints">
                <h3>🔗 API Endpoints</h3>
                <div class="endpoint">GET /health - Health check and system status</div>
                <div class="endpoint">GET /api/info - API information and documentation</div>
                <div class="endpoint">POST /api/nutrition/analyze - Nutrition analysis</div>
                <div class="endpoint">GET /api/diet-plans - Available diet plans</div>
                <div class="endpoint">GET /api/recipes - Recipe database</div>
            </div>
            
            <div class="test-section">
                <h3>🧪 Test Nutrition Analysis</h3>
                <div class="test-form">
                    <div class="form-group">
                        <label for="food">Food Item:</label>
                        <select id="food">
                            <option value="apple">Apple</option>
                            <option value="banana">Banana</option>
                            <option value="chicken">Chicken</option>
                            <option value="salmon">Salmon</option>
                            <option value="broccoli">Broccoli</option>
                            <option value="rice">Rice</option>
                            <option value="egg">Egg</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="quantity">Quantity:</label>
                        <input type="number" id="quantity" value="100" min="1">
                    </div>
                    <div class="form-group">
                        <label for="unit">Unit:</label>
                        <select id="unit">
                            <option value="g">Grams (g)</option>
                            <option value="kg">Kilograms (kg)</option>
                            <option value="oz">Ounces (oz)</option>
                        </select>
                    </div>
                    <button class="test-button" onclick="testNutrition()">Analyze Nutrition</button>
                </div>
                <div id="result" class="result" style="display: none;"></div>
            </div>
        </div>
        
        <div class="footer">
            <p>Powered by Trae New Healthy1 - Your AI Nutrition Assistant</p>
            <p>© 2025 - Advanced Nutrition Technology Platform</p>
        </div>
    </div>
    
    <script>
        async function testNutrition() {
            const food = document.getElementById('food').value;
            const quantity = parseFloat(document.getElementById('quantity').value);
            const unit = document.getElementById('unit').value;
            
            const resultDiv = document.getElementById('result');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<p>🔄 Analyzing nutrition data...</p>';
            
            try {
                const response = await fetch('/api/nutrition/analyze', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ food, quantity, unit, checkHalal: true })
                });
                
                const data = await response.json();
                
                if (data.status === 'success') {
                    resultDiv.innerHTML = ` + "`" + `
                        <h4>📊 Nutrition Analysis Results</h4>
                        <p><strong>Food:</strong> ${data.food} (${data.quantity}${data.unit})</p>
                        <p><strong>Calories:</strong> ${data.calories.toFixed(1)} kcal</p>
                        <p><strong>Protein:</strong> ${data.protein.toFixed(1)}g</p>
                        <p><strong>Carbs:</strong> ${data.carbs.toFixed(1)}g</p>
                        <p><strong>Fat:</strong> ${data.fat.toFixed(1)}g</p>
                        <p><strong>Fiber:</strong> ${data.fiber.toFixed(1)}g</p>
                        <p><strong>Vitamin C:</strong> ${data.vitaminC.toFixed(1)}mg</p>
                        <p><strong>Halal:</strong> ${data.isHalal ? '✅ Yes' : '❌ No'}</p>
                    ` + "`" + `;
                }
            } catch (error) {
                resultDiv.innerHTML = '<p>❌ Error analyzing nutrition data</p>';
            }
        }
    </script>
</body>
</html>`

	c.Data(http.StatusOK, "text/html; charset=utf-8", []byte(html))
}

func healthHandler(c *gin.Context) {
	uptime := time.Since(startTime).Round(time.Second).String()

	response := HealthResponse{
		Status:    "healthy",
		Timestamp: time.Now(),
		Message:   "Trae New Healthy1 - AI Nutrition Platform is running successfully",
		Version:   "1.0.0",
		Uptime:    uptime,
	}

	c.JSON(http.StatusOK, response)
}

func apiInfoHandler(c *gin.Context) {
	info := APIInfo{
		Name:        "Trae New Healthy1",
		Description: "AI-powered nutrition and health management platform with comprehensive food analysis, diet plans, and recipe management",
		Version:     "1.0.0",
		Status:      "active",
		Endpoints: map[string]string{
			"health":     "GET /health - Health check and system status",
			"info":       "GET /api/info - API information and documentation",
			"nutrition":  "POST /api/nutrition/analyze - Comprehensive nutrition analysis",
			"diet-plans": "GET /api/diet-plans - Available diet plans",
			"diet-plan":  "GET /api/diet-plans/:id - Specific diet plan details",
			"recipes":    "GET /api/recipes - Recipe database",
			"recipe":     "GET /api/recipes/:id - Specific recipe details",
		},
		Features: []string{
			"AI-powered nutrition analysis",
			"Halal food verification",
			"Comprehensive nutrient breakdown",
			"Evidence-based diet plans",
			"Healthy recipe database",
			"Multi-language support",
			"Real-time calculations",
			"CORS enabled API",
		},
		Timestamp: time.Now(),
	}

	c.JSON(http.StatusOK, info)
}

func nutritionAnalysisHandler(c *gin.Context) {
	var req NutritionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request format", "details": err.Error()})
		return
	}

	// Get nutrition data
	foodData, exists := nutritionDB[req.Food]
	if !exists {
		foodData = map[string]float64{
			"calories": 100, "protein": 5, "carbs": 15, "fat": 2,
			"fiber": 1, "sugar": 5, "sodium": 10, "calcium": 20, "iron": 1, "vitaminC": 5,
		}
	}

	// Calculate based on quantity (per 100g base)
	multiplier := req.Quantity / 100

	// Check if halal
	isHalal, exists := halalFoods[req.Food]
	if !exists {
		isHalal = false
	}

	response := NutritionResponse{
		Food:      req.Food,
		Quantity:  req.Quantity,
		Unit:      req.Unit,
		Calories:  foodData["calories"] * multiplier,
		Protein:   foodData["protein"] * multiplier,
		Carbs:     foodData["carbs"] * multiplier,
		Fat:       foodData["fat"] * multiplier,
		Fiber:     foodData["fiber"] * multiplier,
		Sugar:     foodData["sugar"] * multiplier,
		Sodium:    foodData["sodium"] * multiplier,
		Calcium:   foodData["calcium"] * multiplier,
		Iron:      foodData["iron"] * multiplier,
		VitaminC:  foodData["vitaminC"] * multiplier,
		IsHalal:   isHalal,
		Status:    "success",
		Message:   "Nutrition analysis completed successfully",
		Timestamp: time.Now(),
	}

	c.JSON(http.StatusOK, response)
}

func dietPlansHandler(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status": "success",
		"count":  len(dietPlans),
		"data":   dietPlans,
	})
}

func dietPlanHandler(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid diet plan ID"})
		return
	}

	for _, plan := range dietPlans {
		if plan.ID == id {
			c.JSON(http.StatusOK, gin.H{
				"status": "success",
				"data":   plan,
			})
			return
		}
	}

	c.JSON(http.StatusNotFound, gin.H{"error": "Diet plan not found"})
}

func recipesHandler(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status": "success",
		"count":  len(recipes),
		"data":   recipes,
	})
}

func recipeHandler(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid recipe ID"})
		return
	}

	for _, recipe := range recipes {
		if recipe.ID == id {
			c.JSON(http.StatusOK, gin.H{
				"status": "success",
				"data":   recipe,
			})
			return
		}
	}

	c.JSON(http.StatusNotFound, gin.H{"error": "Recipe not found"})
}

func main() {
	loadConfig()

	fmt.Printf("🚀 Starting Trae New Healthy1 server...\n")
	fmt.Printf("📍 Environment: %s\n", config.Environment)
	fmt.Printf("🌐 Port: %s\n", config.Port)
	fmt.Printf("🏠 Domain: %s\n", config.Domain)

	router := setupRouter()

	fmt.Printf("✅ Server ready at http://localhost:%s\n", config.Port)
	fmt.Printf("🏥 Health check: http://localhost:%s/health\n", config.Port)
	fmt.Printf("📊 API info: http://localhost:%s/api/info\n", config.Port)

	log.Fatal(router.Run(":" + config.Port))
}
