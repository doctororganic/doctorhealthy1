package tests

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/suite"

	"nutrition-platform/models"
)

// ModelsTestSuite tests model functionality
type ModelsTestSuite struct {
	suite.Suite
}

// SetUpSuite initializes the test suite
func (suite *ModelsTestSuite) SetUpSuite() {
	// Setup test environment
}

// TearDownSuite cleans up after tests
func (suite *ModelsTestSuite) TearDownSuite() {
	// Cleanup resources
}

// TestUserModel tests User model functionality
func (suite *ModelsTestSuite) TestUserModel() {
	user := &models.User{
		ID:       1,
		Username: "testuser",
		Email:    "test@example.com",
		Age:      25,
		Gender:   "male",
		Height:   175.5,
		Weight:   70.0,
	}

	// Test validation
	assert.NotEmpty(suite.T(), user.Username)
	assert.NotEmpty(suite.T(), user.Email)
	assert.Greater(suite.T(), user.Age, 0)
	assert.Greater(suite.T(), user.Height, 0.0)
	assert.Greater(suite.T(), user.Weight, 0.0)

	// Test BMI calculation if method exists
	if user.Height > 0 && user.Weight > 0 {
		expectedBMI := user.Weight / ((user.Height / 100) * (user.Height / 100))
		assert.InDelta(suite.T(), expectedBMI, 22.86, 0.01)
	}
}

// TestFoodModel tests Food model functionality
func (suite *ModelsTestSuite) TestFoodModel() {
	food := &models.Food{
		ID:        1,
		Name:      "Apple",
		Category:  "Fruit",
		Calories:  52,
		Protein:   0.3,
		Carbs:     14.0,
		Fat:       0.2,
		Fiber:     2.4,
		Sugar:     10.4,
		Sodium:    1,
		Potassium: 107,
		Vitamin_C: 4.6,
		Calcium:   6,
		Iron:      0.12,
	}

	// Test validation
	assert.NotEmpty(suite.T(), food.Name)
	assert.NotEmpty(suite.T(), food.Category)
	assert.GreaterOrEqual(suite.T(), food.Calories, 0)
	assert.GreaterOrEqual(suite.T(), food.Protein, 0.0)
	assert.GreaterOrEqual(suite.T(), food.Carbs, 0.0)
	assert.GreaterOrEqual(suite.T(), food.Fat, 0.0)

	// Test nutritional completeness
	totalMacros := food.Protein + food.Carbs + food.Fat
	assert.Greater(suite.T(), totalMacros, 0.0)
}

// TestExerciseModel tests Exercise model functionality
func (suite *ModelsTestSuite) TestExerciseModel() {
	exercise := &models.Exercise{
		ID:              1,
		Name:            "Push-ups",
		Category:        "Strength",
		MuscleGroup:     "Chest",
		Equipment:       "None",
		Difficulty:      "Beginner",
		CaloriesPerHour: 300,
		Instructions:    "Perform push-ups with proper form",
		VideoURL:        "https://example.com/pushups.mp4",
		ImageURL:        "https://example.com/pushups.jpg",
	}

	// Test validation
	assert.NotEmpty(suite.T(), exercise.Name)
	assert.NotEmpty(suite.T(), exercise.Category)
	assert.NotEmpty(suite.T(), exercise.MuscleGroup)
	assert.Greater(suite.T(), exercise.CaloriesPerHour, 0)
	assert.Contains(suite.T(), []string{"Beginner", "Intermediate", "Advanced"}, exercise.Difficulty)
}

// TestMealPlanModel tests MealPlan model functionality
func (suite *ModelsTestSuite) TestMealPlanModel() {
	mealPlan := &models.MealPlan{
		ID:          1,
		UserID:      1,
		Name:        "Weight Loss Plan",
		Description: "A balanced meal plan for weight loss",
		Duration:    7, // 7 days
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
	}

	// Test validation
	assert.NotEmpty(suite.T(), mealPlan.Name)
	assert.Greater(suite.T(), mealPlan.UserID, 0)
	assert.Greater(suite.T(), mealPlan.Duration, 0)
	assert.False(suite.T(), mealPlan.CreatedAt.IsZero())
}

// TestWorkoutPlanModel tests WorkoutPlan model functionality
func (suite *ModelsTestSuite) TestWorkoutPlanModel() {
	workoutPlan := &models.WorkoutPlan{
		ID:          1,
		UserID:      1,
		Name:        "Beginner Strength Training",
		Description: "A beginner-friendly strength training program",
		Duration:    4, // 4 weeks
		Difficulty:  "Beginner",
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
	}

	// Test validation
	assert.NotEmpty(suite.T(), workoutPlan.Name)
	assert.Greater(suite.T(), workoutPlan.UserID, 0)
	assert.Greater(suite.T(), workoutPlan.Duration, 0)
	assert.Contains(suite.T(), []string{"Beginner", "Intermediate", "Advanced"}, workoutPlan.Difficulty)
	assert.False(suite.T(), workoutPlan.CreatedAt.IsZero())
}

// TestUserFoodLogModel tests UserFoodLog model functionality
func (suite *ModelsTestSuite) TestUserFoodLogModel() {
	foodLog := &models.UserFoodLog{
		ID:        1,
		UserID:    1,
		FoodID:    1,
		Quantity:  150.0, // grams
		MealType:  "breakfast",
		LoggedAt:  time.Now(),
		CreatedAt: time.Now(),
	}

	// Test validation
	assert.Greater(suite.T(), foodLog.UserID, 0)
	assert.Greater(suite.T(), foodLog.FoodID, 0)
	assert.Greater(suite.T(), foodLog.Quantity, 0.0)
	assert.Contains(suite.T(), []string{"breakfast", "lunch", "dinner", "snack"}, foodLog.MealType)
	assert.False(suite.T(), foodLog.LoggedAt.IsZero())
}

// TestUserExerciseLogModel tests UserExerciseLog model functionality
func (suite *ModelsTestSuite) TestUserExerciseLogModel() {
	exerciseLog := &models.UserExerciseLog{
		ID:         1,
		UserID:     1,
		ExerciseID: 1,
		Duration:   30, // minutes
		Sets:       3,
		Reps:       15,
		Weight:     0, // bodyweight exercise
		LoggedAt:   time.Now(),
		CreatedAt:  time.Now(),
	}

	// Test validation
	assert.Greater(suite.T(), exerciseLog.UserID, 0)
	assert.Greater(suite.T(), exerciseLog.ExerciseID, 0)
	assert.Greater(suite.T(), exerciseLog.Duration, 0)
	assert.GreaterOrEqual(suite.T(), exerciseLog.Sets, 0)
	assert.GreaterOrEqual(suite.T(), exerciseLog.Reps, 0)
	assert.GreaterOrEqual(suite.T(), exerciseLog.Weight, 0.0)
	assert.False(suite.T(), exerciseLog.LoggedAt.IsZero())
}

// TestAPIKeyModel tests APIKey model functionality
func (suite *ModelsTestSuite) TestAPIKeyModel() {
	apiKey := &models.APIKey{
		ID:         1,
		UserID:     1,
		KeyHash:    "hashed_key_value",
		Name:       "Mobile App Key",
		Scopes:     []string{"read", "write"},
		IsActive:   true,
		ExpiresAt:  time.Now().Add(30 * 24 * time.Hour), // 30 days
		CreatedAt:  time.Now(),
		LastUsedAt: time.Now(),
	}

	// Test validation
	assert.Greater(suite.T(), apiKey.UserID, 0)
	assert.NotEmpty(suite.T(), apiKey.KeyHash)
	assert.NotEmpty(suite.T(), apiKey.Name)
	assert.NotEmpty(suite.T(), apiKey.Scopes)
	assert.True(suite.T(), apiKey.IsActive)
	assert.True(suite.T(), apiKey.ExpiresAt.After(time.Now()))
}

// TestSystemMetricsModel tests SystemMetrics model functionality
func (suite *ModelsTestSuite) TestSystemMetricsModel() {
	metrics := &models.SystemMetrics{
		ID:                  1,
		CPUUsage:            45.5,
		MemoryUsage:         67.8,
		DiskUsage:           23.4,
		ActiveUsers:         150,
		RequestsPerHour:     5000,
		ErrorRate:           0.5,
		ResponseTime:        120.5,
		DatabaseConnections: 25,
		Timestamp:           time.Now(),
	}

	// Test validation
	assert.GreaterOrEqual(suite.T(), metrics.CPUUsage, 0.0)
	assert.LessOrEqual(suite.T(), metrics.CPUUsage, 100.0)
	assert.GreaterOrEqual(suite.T(), metrics.MemoryUsage, 0.0)
	assert.LessOrEqual(suite.T(), metrics.MemoryUsage, 100.0)
	assert.GreaterOrEqual(suite.T(), metrics.DiskUsage, 0.0)
	assert.GreaterOrEqual(suite.T(), metrics.ActiveUsers, 0)
	assert.GreaterOrEqual(suite.T(), metrics.RequestsPerHour, 0)
	assert.GreaterOrEqual(suite.T(), metrics.ErrorRate, 0.0)
	assert.GreaterOrEqual(suite.T(), metrics.ResponseTime, 0.0)
	assert.GreaterOrEqual(suite.T(), metrics.DatabaseConnections, 0)
	assert.False(suite.T(), metrics.Timestamp.IsZero())
}

// TestModelsTestSuite runs the test suite
func TestModelsTestSuite(t *testing.T) {
	suite.Run(t, new(ModelsTestSuite))
}

// BenchmarkUserModelCreation benchmarks user model creation
func BenchmarkUserModelCreation(b *testing.B) {
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		user := &models.User{
			ID:       1,
			Username: "testuser",
			Email:    "test@example.com",
			Age:      25,
			Gender:   "male",
			Height:   175.5,
			Weight:   70.0,
		}
		_ = user
	}
}

// BenchmarkFoodModelCreation benchmarks food model creation
func BenchmarkFoodModelCreation(b *testing.B) {
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		food := &models.Food{
			ID:        1,
			Name:      "Apple",
			Category:  "Fruit",
			Calories:  52,
			Protein:   0.3,
			Carbs:     14.0,
			Fat:       0.2,
			Fiber:     2.4,
			Sugar:     10.4,
			Sodium:    1,
			Potassium: 107,
			Vitamin_C: 4.6,
			Calcium:   6,
			Iron:      0.12,
		}
		_ = food
	}
}
