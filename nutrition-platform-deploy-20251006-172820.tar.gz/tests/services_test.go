package tests

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/suite"

	"nutrition-platform/models"
	"nutrition-platform/services"
)

// MockRepository represents a mock repository for testing
type MockRepository struct {
	mock.Mock
}

func (m *MockRepository) GetUser(id int) (*models.User, error) {
	args := m.Called(id)
	return args.Get(0).(*models.User), args.Error(1)
}

func (m *MockRepository) CreateUser(user *models.User) error {
	args := m.Called(user)
	return args.Error(0)
}

func (m *MockRepository) UpdateUser(user *models.User) error {
	args := m.Called(user)
	return args.Error(0)
}

func (m *MockRepository) DeleteUser(id int) error {
	args := m.Called(id)
	return args.Error(0)
}

func (m *MockRepository) GetFood(id int) (*models.Food, error) {
	args := m.Called(id)
	return args.Get(0).(*models.Food), args.Error(1)
}

func (m *MockRepository) SearchFoods(query string) ([]*models.Food, error) {
	args := m.Called(query)
	return args.Get(0).([]*models.Food), args.Error(1)
}

func (m *MockRepository) CreateFoodLog(log *models.UserFoodLog) error {
	args := m.Called(log)
	return args.Error(0)
}

func (m *MockRepository) GetUserFoodLogs(userID int, date time.Time) ([]*models.UserFoodLog, error) {
	args := m.Called(userID, date)
	return args.Get(0).([]*models.UserFoodLog), args.Error(1)
}

// ServicesTestSuite tests service functionality
type ServicesTestSuite struct {
	suite.Suite
	mockRepo    *MockRepository
	userService *services.UserService
	foodService *services.FoodService
	logService  *services.LogService
}

// SetUpSuite initializes the test suite
func (suite *ServicesTestSuite) SetUpSuite() {
	suite.mockRepo = new(MockRepository)
	suite.userService = services.NewUserService(suite.mockRepo)
	suite.foodService = services.NewFoodService(suite.mockRepo)
	suite.logService = services.NewLogService(suite.mockRepo)
}

// SetUpTest runs before each test
func (suite *ServicesTestSuite) SetUpTest() {
	suite.mockRepo.ExpectedCalls = nil
}

// TearDownSuite cleans up after tests
func (suite *ServicesTestSuite) TearDownSuite() {
	// Cleanup resources
}

// TestUserServiceGetUser tests UserService GetUser method
func (suite *ServicesTestSuite) TestUserServiceGetUser() {
	// Setup mock
	expectedUser := &models.User{
		ID:       1,
		Username: "testuser",
		Email:    "test@example.com",
		Age:      25,
		Gender:   "male",
		Height:   175.5,
		Weight:   70.0,
	}
	suite.mockRepo.On("GetUser", 1).Return(expectedUser, nil)

	// Execute service method
	user, err := suite.userService.GetUser(1)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.NotNil(suite.T(), user)
	assert.Equal(suite.T(), expectedUser.ID, user.ID)
	assert.Equal(suite.T(), expectedUser.Username, user.Username)
	assert.Equal(suite.T(), expectedUser.Email, user.Email)

	suite.mockRepo.AssertExpectations(suite.T())
}

// TestUserServiceCreateUser tests UserService CreateUser method
func (suite *ServicesTestSuite) TestUserServiceCreateUser() {
	// Setup test data
	newUser := &models.User{
		Username: "newuser",
		Email:    "newuser@example.com",
		Age:      30,
		Gender:   "female",
		Height:   165.0,
		Weight:   60.0,
	}

	suite.mockRepo.On("CreateUser", newUser).Return(nil)

	// Execute service method
	err := suite.userService.CreateUser(newUser)

	// Assertions
	assert.NoError(suite.T(), err)

	suite.mockRepo.AssertExpectations(suite.T())
}

// TestUserServiceValidateUser tests user validation logic
func (suite *ServicesTestSuite) TestUserServiceValidateUser() {
	// Test valid user
	validUser := &models.User{
		Username: "validuser",
		Email:    "valid@example.com",
		Age:      25,
		Gender:   "male",
		Height:   175.0,
		Weight:   70.0,
	}

	err := suite.userService.ValidateUser(validUser)
	assert.NoError(suite.T(), err)

	// Test invalid user - missing username
	invalidUser := &models.User{
		Email:  "test@example.com",
		Age:    25,
		Gender: "male",
		Height: 175.0,
		Weight: 70.0,
	}

	err = suite.userService.ValidateUser(invalidUser)
	assert.Error(suite.T(), err)
	assert.Contains(suite.T(), err.Error(), "username")

	// Test invalid user - invalid email
	invalidEmailUser := &models.User{
		Username: "testuser",
		Email:    "invalid-email",
		Age:      25,
		Gender:   "male",
		Height:   175.0,
		Weight:   70.0,
	}

	err = suite.userService.ValidateUser(invalidEmailUser)
	assert.Error(suite.T(), err)
	assert.Contains(suite.T(), err.Error(), "email")

	// Test invalid user - negative age
	negativeAgeUser := &models.User{
		Username: "testuser",
		Email:    "test@example.com",
		Age:      -5,
		Gender:   "male",
		Height:   175.0,
		Weight:   70.0,
	}

	err = suite.userService.ValidateUser(negativeAgeUser)
	assert.Error(suite.T(), err)
	assert.Contains(suite.T(), err.Error(), "age")
}

// TestUserServiceCalculateBMI tests BMI calculation
func (suite *ServicesTestSuite) TestUserServiceCalculateBMI() {
	user := &models.User{
		Height: 175.0, // cm
		Weight: 70.0,  // kg
	}

	bmi := suite.userService.CalculateBMI(user)
	expectedBMI := 70.0 / ((175.0 / 100) * (175.0 / 100))

	assert.InDelta(suite.T(), expectedBMI, bmi, 0.01)
	assert.InDelta(suite.T(), 22.86, bmi, 0.01)
}

// TestFoodServiceGetFood tests FoodService GetFood method
func (suite *ServicesTestSuite) TestFoodServiceGetFood() {
	// Setup mock
	expectedFood := &models.Food{
		ID:        1,
		Name:      "Apple",
		Category:  "Fruit",
		Calories:  52,
		Protein:   0.3,
		Carbs:     14.0,
		Fat:       0.2,
		Fiber:     2.4,
		Sugar:     10.4,
		Sodium:    1,
		Potassium: 107,
		Vitamin_C: 4.6,
		Calcium:   6,
		Iron:      0.12,
	}
	suite.mockRepo.On("GetFood", 1).Return(expectedFood, nil)

	// Execute service method
	food, err := suite.foodService.GetFood(1)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.NotNil(suite.T(), food)
	assert.Equal(suite.T(), expectedFood.ID, food.ID)
	assert.Equal(suite.T(), expectedFood.Name, food.Name)
	assert.Equal(suite.T(), expectedFood.Calories, food.Calories)

	suite.mockRepo.AssertExpectations(suite.T())
}

// TestFoodServiceSearchFoods tests FoodService SearchFoods method
func (suite *ServicesTestSuite) TestFoodServiceSearchFoods() {
	// Setup mock
	expectedFoods := []*models.Food{
		{
			ID:       1,
			Name:     "Apple",
			Category: "Fruit",
			Calories: 52,
		},
		{
			ID:       2,
			Name:     "Banana",
			Category: "Fruit",
			Calories: 89,
		},
	}
	suite.mockRepo.On("SearchFoods", "fruit").Return(expectedFoods, nil)

	// Execute service method
	foods, err := suite.foodService.SearchFoods("fruit")

	// Assertions
	assert.NoError(suite.T(), err)
	assert.NotNil(suite.T(), foods)
	assert.Len(suite.T(), foods, 2)
	assert.Equal(suite.T(), expectedFoods[0].Name, foods[0].Name)
	assert.Equal(suite.T(), expectedFoods[1].Name, foods[1].Name)

	suite.mockRepo.AssertExpectations(suite.T())
}

// TestFoodServiceCalculateNutrition tests nutrition calculation
func (suite *ServicesTestSuite) TestFoodServiceCalculateNutrition() {
	food := &models.Food{
		Calories: 52,   // per 100g
		Protein:  0.3,  // per 100g
		Carbs:    14.0, // per 100g
		Fat:      0.2,  // per 100g
	}

	quantity := 150.0 // grams

	nutrition := suite.foodService.CalculateNutrition(food, quantity)

	// Expected values for 150g
	expectedCalories := 52 * (quantity / 100)
	expectedProtein := 0.3 * (quantity / 100)
	expectedCarbs := 14.0 * (quantity / 100)
	expectedFat := 0.2 * (quantity / 100)

	assert.InDelta(suite.T(), expectedCalories, nutrition.Calories, 0.01)
	assert.InDelta(suite.T(), expectedProtein, nutrition.Protein, 0.01)
	assert.InDelta(suite.T(), expectedCarbs, nutrition.Carbs, 0.01)
	assert.InDelta(suite.T(), expectedFat, nutrition.Fat, 0.01)
}

// TestLogServiceCreateFoodLog tests LogService CreateFoodLog method
func (suite *ServicesTestSuite) TestLogServiceCreateFoodLog() {
	// Setup test data
	foodLog := &models.UserFoodLog{
		UserID:    1,
		FoodID:    1,
		Quantity:  150.0,
		MealType:  "breakfast",
		LoggedAt:  time.Now(),
		CreatedAt: time.Now(),
	}

	suite.mockRepo.On("CreateFoodLog", foodLog).Return(nil)

	// Execute service method
	err := suite.logService.CreateFoodLog(foodLog)

	// Assertions
	assert.NoError(suite.T(), err)

	suite.mockRepo.AssertExpectations(suite.T())
}

// TestLogServiceValidateFoodLog tests food log validation
func (suite *ServicesTestSuite) TestLogServiceValidateFoodLog() {
	// Test valid food log
	validLog := &models.UserFoodLog{
		UserID:   1,
		FoodID:   1,
		Quantity: 150.0,
		MealType: "breakfast",
		LoggedAt: time.Now(),
	}

	err := suite.logService.ValidateFoodLog(validLog)
	assert.NoError(suite.T(), err)

	// Test invalid food log - zero quantity
	invalidLog := &models.UserFoodLog{
		UserID:   1,
		FoodID:   1,
		Quantity: 0,
		MealType: "breakfast",
		LoggedAt: time.Now(),
	}

	err = suite.logService.ValidateFoodLog(invalidLog)
	assert.Error(suite.T(), err)
	assert.Contains(suite.T(), err.Error(), "quantity")

	// Test invalid food log - invalid meal type
	invalidMealTypeLog := &models.UserFoodLog{
		UserID:   1,
		FoodID:   1,
		Quantity: 150.0,
		MealType: "invalid_meal",
		LoggedAt: time.Now(),
	}

	err = suite.logService.ValidateFoodLog(invalidMealTypeLog)
	assert.Error(suite.T(), err)
	assert.Contains(suite.T(), err.Error(), "meal_type")
}

// TestLogServiceGetDailyNutrition tests daily nutrition calculation
func (suite *ServicesTestSuite) TestLogServiceGetDailyNutrition() {
	// Setup mock data
	date := time.Now().Truncate(24 * time.Hour)
	foodLogs := []*models.UserFoodLog{
		{
			UserID:   1,
			FoodID:   1,
			Quantity: 150.0,
			MealType: "breakfast",
			LoggedAt: date,
		},
		{
			UserID:   1,
			FoodID:   2,
			Quantity: 200.0,
			MealType: "lunch",
			LoggedAt: date,
		},
	}

	suite.mockRepo.On("GetUserFoodLogs", 1, date).Return(foodLogs, nil)

	// Mock food data for nutrition calculation
	apple := &models.Food{ID: 1, Calories: 52, Protein: 0.3, Carbs: 14.0, Fat: 0.2}
	banana := &models.Food{ID: 2, Calories: 89, Protein: 1.1, Carbs: 23.0, Fat: 0.3}

	suite.mockRepo.On("GetFood", 1).Return(apple, nil)
	suite.mockRepo.On("GetFood", 2).Return(banana, nil)

	// Execute service method
	nutrition, err := suite.logService.GetDailyNutrition(1, date)

	// Assertions
	assert.NoError(suite.T(), err)
	assert.NotNil(suite.T(), nutrition)

	// Calculate expected values
	expectedCalories := (52 * 1.5) + (89 * 2.0) // 150g apple + 200g banana
	assert.InDelta(suite.T(), expectedCalories, nutrition.TotalCalories, 1.0)

	suite.mockRepo.AssertExpectations(suite.T())
}

// TestServicesConcurrency tests service methods under concurrent access
func (suite *ServicesTestSuite) TestServicesConcurrency() {
	// Setup mock
	user := &models.User{
		ID:       1,
		Username: "testuser",
		Email:    "test@example.com",
	}
	suite.mockRepo.On("GetUser", 1).Return(user, nil)

	// Run concurrent requests
	done := make(chan bool, 10)
	for i := 0; i < 10; i++ {
		go func() {
			defer func() { done <- true }()
			_, err := suite.userService.GetUser(1)
			assert.NoError(suite.T(), err)
		}()
	}

	// Wait for all goroutines to complete
	for i := 0; i < 10; i++ {
		<-done
	}

	suite.mockRepo.AssertExpectations(suite.T())
}

// TestServicesTestSuite runs the test suite
func TestServicesTestSuite(t *testing.T) {
	suite.Run(t, new(ServicesTestSuite))
}

// BenchmarkUserServiceGetUser benchmarks UserService GetUser method
func BenchmarkUserServiceGetUser(b *testing.B) {
	mockRepo := new(MockRepository)
	userService := services.NewUserService(mockRepo)

	user := &models.User{
		ID:       1,
		Username: "testuser",
		Email:    "test@example.com",
	}
	mockRepo.On("GetUser", 1).Return(user, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		userService.GetUser(1)
	}
}

// BenchmarkFoodServiceCalculateNutrition benchmarks nutrition calculation
func BenchmarkFoodServiceCalculateNutrition(b *testing.B) {
	mockRepo := new(MockRepository)
	foodService := services.NewFoodService(mockRepo)

	food := &models.Food{
		Calories: 52,
		Protein:  0.3,
		Carbs:    14.0,
		Fat:      0.2,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		foodService.CalculateNutrition(food, 150.0)
	}
}

// TestServiceTimeout tests service method timeouts
func (suite *ServicesTestSuite) TestServiceTimeout() {
	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel()

	// Simulate a slow operation
	suite.mockRepo.On("GetUser", 1).Return((*models.User)(nil), context.DeadlineExceeded)

	// Execute service method with context
	_, err := suite.userService.GetUserWithContext(ctx, 1)

	// Assertions
	assert.Error(suite.T(), err)
	assert.Equal(suite.T(), context.DeadlineExceeded, err)

	suite.mockRepo.AssertExpectations(suite.T())
}
